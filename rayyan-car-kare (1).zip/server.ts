import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Booking (Mock Google Sheets Integration)
  app.post("/api/book", async (req, res) => {
    try {
      const { name, phone, carType, location, package: pkg } = req.body;
      
      console.log("New Booking Request Received:");
      console.table({ name, phone, carType, location, package: pkg });

      // TO CONNECT DIRECTLY TO GOOGLE SHEETS:
      // You can use a Google Apps Script Web App URL and fetch it here
      /*
      const GOOGLE_SCRIPT_URL = "YOUR_APPS_SCRIPT_WEB_APP_URL";
      await fetch(GOOGLE_SCRIPT_URL, {
        method: "POST",
        body: JSON.stringify(req.body)
      });
      */

      res.status(200).json({ 
        success: true, 
        message: "Booking request logged successfully. Connect a Google Apps Script to the /api/book endpoint to sync with Sheets." 
      });
    } catch (error) {
      console.error("Booking error:", error);
      res.status(500).json({ success: false, message: "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serving static files in production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
