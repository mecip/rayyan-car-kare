import { motion } from "motion/react";
import { MessageCircle, Phone, MapPin, Mail, Clock, HelpCircle, ChevronDown } from "lucide-react";
import { useState } from "react";
import { CONTACT_INFO } from "@/src/constants";
import { WhatsAppIcon } from "../components/WhatsAppIcon";
import { BookingForm } from "../components/BookingForm";
import { cn } from "@/src/lib/utils";

const faqs = [
  { 
    q: "How long does a detailing session take?", 
    a: "A standard Rubbing & Polish or Wax Polish package usually takes between 3 to 5 hours, depending on the car's condition and size." 
  },
  { 
    q: "Do you need access to water and electricity?", 
    a: "Yes, we require basic access to a water source and an electrical point within 20-30 meters of the vehicle location." 
  },
  { 
    q: "What areas in Chennai do you cover?", 
    a: "We currently provide doorstep service across major areas including Saligramam, Vadapalani, T-Nagar, Anna Nagar, and surrounding urban limits." 
  },
  { 
    q: "Is there any extra charge for SUV or Luxury cars?", 
    a: "Our listed prices are base rates. For larger SUVs or heavily soiled luxury vehicles, a small nominal fee may apply based on the additional time and material required." 
  },
];

export default function Contact() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className="pt-32 pb-24 px-4 md:px-8 max-w-7xl mx-auto min-h-screen">
      <div className="text-center mb-16">
        <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter uppercase leading-none">
          Get In <br/><span className="text-gold">Touch</span>
        </h1>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] max-w-2xl mx-auto">
          Book your slot or ask us anything. Professional support available 12/7.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-24">
        {/* Contact Links Card */}
        <div className="md:col-span-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Phone, label: "Call Us", value: CONTACT_INFO.displayPhone, href: `tel:${CONTACT_INFO.phone}` },
            { icon: WhatsAppIcon, label: "WhatsApp", value: "Click to Chat", href: `https://wa.me/${CONTACT_INFO.whatsapp}` },
            { icon: MapPin, label: "Service Area", value: "Chennai Urban Wide", href: "#" },
            { icon: Clock, label: "Availability", value: "8AM - 8PM Daily", href: "#" },
          ].map((item, i) => (
            <a
              key={i}
              href={item.href}
              className="bento-card group hover:border-gold/30 transition-all flex flex-col items-center text-center py-10"
            >
              <div className="w-12 h-12 bg-zinc-800 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-gold/10 transition-all">
                <item.icon className="w-5 h-5 text-gold" />
              </div>
              <h4 className="text-zinc-600 font-black text-[10px] uppercase tracking-[0.2em] mb-2">{item.label}</h4>
              <p className="text-white font-black text-lg uppercase tracking-tighter">{item.value}</p>
            </a>
          ))}
        </div>

        {/* Booking Form (Large Card) */}
        <div className="md:col-span-8">
          <BookingForm />
        </div>

        {/* Business Info (Side Card) */}
        <div className="md:col-span-4 bento-card border-zinc-800 flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-black text-white mb-6 uppercase tracking-tighter">Office Info</h3>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <MapPin className="w-5 h-5 text-gold shrink-0 mt-1" />
                <p className="text-zinc-500 font-bold uppercase tracking-widest text-[10px] leading-relaxed">
                  {CONTACT_INFO.address}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <Mail className="w-5 h-5 text-gold shrink-0" />
                <p className="text-zinc-400 font-black text-[10px] uppercase tracking-widest">{CONTACT_INFO.email}</p>
              </div>
            </div>
          </div>
          
          <div className="mt-12 bg-black p-6 rounded-2xl border border-zinc-800">
            <h4 className="text-white font-black text-xs uppercase tracking-widest mb-4">Support Hours</h4>
            <ul className="space-y-3">
              <li className="flex justify-between text-[11px] font-bold uppercase tracking-tighter">
                <span className="text-zinc-600">Daily</span>
                <span className="text-gold">08:00 — 20:00</span>
              </li>
              <li className="pt-2 border-t border-zinc-800 text-[10px] text-zinc-600 font-bold uppercase tracking-widest text-center">
                Response within 30 mins
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <section className="bento-card border-zinc-800 p-8 md:p-16">
        <div className="flex items-center space-x-4 mb-12">
          <HelpCircle className="w-8 h-8 text-gold" />
          <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Common Questions</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
          {faqs.map((faq, i) => (
            <div key={i} className="group border-b border-zinc-800 pb-8">
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between text-left"
              >
                <span className={cn(
                  "font-black text-sm uppercase tracking-tight transition-colors", 
                  openFaq === i ? "text-gold" : "text-white group-hover:text-gold"
                )}>
                  {faq.q}
                </span>
                <ChevronDown className={cn("w-4 h-4 text-zinc-500 transition-transform duration-300", openFaq === i && "rotate-180")} />
              </button>
              <motion.div
                initial={false}
                animate={{ height: openFaq === i ? "auto" : 0, opacity: openFaq === i ? 1 : 0 }}
                className="overflow-hidden"
              >
                <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-wide leading-relaxed pt-6">
                  {faq.a}
                </p>
              </motion.div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
