import { motion } from "motion/react";
import { ArrowRight, CheckCircle2, Star, Sparkles, Clock, ShieldCheck, MapPinned, Phone } from "lucide-react";
import { Link } from "react-router-dom";
import { SERVICES, CONTACT_INFO } from "@/src/constants";
import { BookingForm } from "../components/BookingForm";

export default function Home() {
  return (
    <div className="pt-28 pb-10 px-4 md:px-8 max-w-7xl mx-auto flex flex-col min-h-screen">
      <div className="grid grid-cols-1 md:grid-cols-12 md:grid-rows-6 gap-4 flex-grow">
        {/* Hero Section (Card 1) */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-8 md:row-span-3 bento-card relative overflow-hidden group"
        >
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent z-10" />
            <video
              autoPlay
              muted
              loop
              playsInline
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
            >
              <source src="https://assets.mixkit.co/videos/preview/mixkit-hand-polishing-a-car-34509-large.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>

          <div className="relative z-20 h-full flex flex-col justify-center">
            <div className="inline-flex items-center space-x-2 bg-gold/10 border border-gold/30 px-3 py-1 rounded-full text-gold text-[10px] font-bold uppercase tracking-widest mb-6 w-fit">
              <Sparkles className="w-3 h-3" />
              <span>Premium Doorstep Detailing</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tighter leading-none uppercase">
              Premium Car Care at <br />
              <span className="text-gold">Your Doorstep</span>
            </h2>
            <p className="text-zinc-400 mb-8 max-w-md text-sm font-medium leading-relaxed">
              Experience the luxury of professional detailing without leaving your home. 
              We bring the showroom shine to you in Chennai.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 items-start sm:items-center">
              <Link
                to="/services"
                className="bg-gold hover:brightness-110 text-black px-8 py-3 rounded-xl font-black uppercase text-xs tracking-widest transition-all"
              >
                Explore Packages
              </Link>
              <div className="flex -space-x-2 items-center">
                {[1, 2, 3].map((_, i) => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-black bg-zinc-800 flex items-center justify-center text-[10px] font-black text-gold">5★</div>
                ))}
                <span className="ml-4 text-[10px] font-black uppercase tracking-widest text-zinc-500 underline decoration-gold">500+ Happy Clients</span>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Rubbing Package (Card 2) */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="md:col-span-4 md:row-span-3 bento-card-gold flex flex-col justify-between group"
        >
          <div>
            <div className="flex justify-between items-start">
              <h3 className="text-3xl font-black tracking-tighter leading-none uppercase">
                RUBBING & <br /> POLISH
              </h3>
              <span className="bg-black text-gold text-[10px] font-black px-2 py-1 rounded uppercase tracking-tighter">BEST VALUE</span>
            </div>
            <p className="mt-2 text-sm font-bold opacity-80 italic uppercase tracking-tighter">Deep Restoration Package</p>
            <ul className="mt-6 space-y-3 text-xs font-bold uppercase tracking-tighter">
              <li className="flex items-center space-x-2"><CheckCircle2 className="w-4 h-4" /> <span>3M Body Rubbing</span></li>
              <li className="flex items-center space-x-2"><CheckCircle2 className="w-4 h-4" /> <span>Dust & Tar Removal</span></li>
              <li className="flex items-center space-x-2"><CheckCircle2 className="w-4 h-4" /> <span>Interior Deep Clean</span></li>
              <li className="flex items-center space-x-2"><CheckCircle2 className="w-4 h-4" /> <span>Tyre & Dash Polish</span></li>
            </ul>
          </div>
          <div className="pt-6 border-t border-black/10">
            <div className="text-4xl font-black tracking-tighter">₹5,999</div>
            <Link 
              to="/contact?package=rubbing"
              className="w-full mt-4 bg-black text-gold py-4 rounded-xl font-black uppercase text-xs tracking-[0.2em] inline-block text-center hover:scale-[1.02] transition-transform"
            >
              Book Package
            </Link>
          </div>
        </motion.div>

        {/* Contact Info (Card 3) */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="md:col-span-4 md:row-span-3 bento-card flex flex-col"
        >
          <h3 className="text-gold font-black text-xl mb-6 uppercase tracking-tighter">Get in Touch</h3>
          <div className="space-y-6 flex-grow">
            <div className="flex items-center space-x-4 text-sm group">
              <div className="p-3 bg-zinc-800 rounded-xl group-hover:bg-gold/10 transition-colors">
                <MapPinned className="w-5 h-5 text-gold" />
              </div>
              <p className="text-zinc-400 font-bold uppercase tracking-tighter text-xs">
                {CONTACT_INFO.address.split(',').map((part, i) => (
                  <span key={i} className="block">{part.trim()}</span>
                ))}
              </p>
            </div>
            <div className="flex items-center space-x-4 text-sm group">
              <div className="p-3 bg-zinc-800 rounded-xl group-hover:bg-gold/10 transition-colors">
                <Phone className="w-5 h-5 text-gold" />
              </div>
              <p className="text-zinc-400 font-black tracking-widest">{CONTACT_INFO.displayPhone}</p>
            </div>
          </div>
          <div className="mt-6 p-5 bg-zinc-800/30 rounded-2xl border border-zinc-700/50">
            <p className="text-[10px] text-zinc-500 uppercase font-black tracking-[0.2em] mb-2">Operating Hours</p>
            <div className="flex justify-between text-xs font-bold uppercase tracking-tighter">
              <span className="text-zinc-400">Mon — Sun</span>
              <span className="text-gold">8:00 AM - 8:00 PM</span>
            </div>
          </div>
        </motion.div>

        {/* Wax Package (Card 4) */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="md:col-span-4 md:row-span-3 bento-card flex flex-col justify-between"
        >
          <div>
            <h3 className="text-2xl font-black uppercase tracking-tighter leading-none">
              WAX POLISH <br />
              <span className="text-zinc-500">MAINTENANCE</span>
            </h3>
            <ul className="mt-6 space-y-3 text-[11px] text-zinc-400 font-bold uppercase tracking-widest">
              <li className="flex items-center space-x-2"><div className="w-1.5 h-1.5 rounded-full bg-gold" /> <span>Full Body Wax Polish</span></li>
              <li className="flex items-center space-x-2"><div className="w-1.5 h-1.5 rounded-full bg-gold" /> <span>Exterior Foam Wash</span></li>
              <li className="flex items-center space-x-2"><div className="w-1.5 h-1.5 rounded-full bg-gold" /> <span>Interior Vacuum</span></li>
              <li className="flex items-center space-x-2"><div className="w-1.5 h-1.5 rounded-full bg-gold" /> <span>Plastic Dress-up</span></li>
            </ul>
          </div>
          <div className="pt-6">
            <div className="text-3xl font-black tracking-tighter text-white">₹2,999</div>
            <Link 
              to="/services"
              className="w-full mt-4 border border-zinc-700 hover:bg-zinc-800 py-3 rounded-xl font-black uppercase text-[10px] tracking-[0.2em] inline-block text-center transition-all"
            >
              Full Details
            </Link>
          </div>
        </motion.div>

        {/* Why Choose Us (Card 5) */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="md:col-span-4 md:row-span-3 bento-card relative overflow-hidden flex flex-col"
        >
          <div className="mb-6 flex justify-between items-start">
            <h3 className="text-xl font-black uppercase tracking-tighter text-white">Why Choose Us?</h3>
            <div className="bg-white px-2 py-1 rounded flex items-center">
               <span className="text-[10px] font-black text-gold">3M</span>
               <span className="text-[8px] font-bold text-black ml-1">QUALITY</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 mb-4 flex-grow">
            {[
              { icon: iMapPinned, emoji: "🏠", title: "Doorstep\nService" },
              { icon: iShieldCheck, emoji: "🛠️", title: "Expert\nDetailers" },
              { icon: iSparkles, emoji: "✨", title: "Premium\nProducts" },
              { icon: iStar, emoji: "💎", title: "Showroom\nFinish" },
            ].map((item, i) => (
              <div key={i} className="p-4 bg-zinc-800/50 rounded-2xl border border-zinc-700/30 group hover:border-gold/30 transition-colors">
                <div className="text-2xl mb-2">{item.emoji}</div>
                <p className="text-[10px] font-black uppercase leading-tight tracking-widest text-zinc-400 group-hover:text-gold transition-colors">
                  {item.title.split('\n').map((line, j) => (
                    <span key={j} className="block">{line}</span>
                  ))}
                </p>
              </div>
            ))}
          </div>
          
          {/* 3M Branding Image Integration */}
          <div className="mt-auto p-4 bg-black/40 rounded-2xl border border-white/5 flex items-center space-x-3 group hover:border-gold/30 transition-all">
            <div className="w-12 h-12 bg-gold rounded-lg flex items-center justify-center shrink-0 font-black text-black italic text-xl shadow-lg shadow-gold/20 group-hover:scale-110 transition-transform">
              3M
            </div>
            <div>
              <p className="text-[9px] font-black uppercase tracking-widest text-white leading-tight">
                Authentic 3M Products
              </p>
              <p className="text-[8px] font-bold text-zinc-500 uppercase tracking-tighter">
                We use global standard car polish
              </p>
            </div>
          </div>
          
          {/* Floating Summer Offer Badge */}
          <div className="absolute -bottom-2 -right-4 bg-gold px-6 py-2 rounded-lg font-black text-xs rotate-[-8deg] shadow-xl text-black uppercase tracking-tighter z-20">
            SUMMER OFFER: -10% OFF
          </div>
        </motion.div>
      </div>

      {/* Showroom Excellence Section (Video Section) */}
      <motion.section
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mt-4 bento-card relative overflow-hidden min-h-[400px] flex items-center justify-center text-center p-12"
      >
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black/60 z-10" />
          <video
            autoPlay
            muted
            loop
            playsInline
            className="w-full h-full object-cover"
          >
            <source src="https://assets.mixkit.co/videos/preview/mixkit-hand-polishing-a-car-34505-large.mp4" type="video/mp4" />
          </video>
        </div>
        
        <div className="relative z-20 max-w-2xl">
          <Sparkles className="w-10 h-10 text-gold mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl font-black text-white mb-6 uppercase tracking-tighter">Showroom Finish In Action</h2>
          <p className="text-zinc-400 font-bold uppercase tracking-widest text-sm mb-8 leading-relaxed">
            Watch our expert detailers transform dull surfaces into mirror-like finishes using authentic 3M products and professional techniques.
          </p>
          <div className="inline-flex items-center space-x-3 bg-gold text-black px-6 py-3 rounded-full font-black text-xs uppercase tracking-widest shadow-lg shadow-gold/40">
            <span>5,000+ Cars Restored</span>
          </div>
        </div>
      </motion.section>
    </div>
  );
}

// Internal icons to avoid import errors if not already present
const iMapPinned = MapPinned;
const iShieldCheck = ShieldCheck;
const iSparkles = Sparkles;
const iStar = Star;

