import { motion } from "motion/react";
import { Camera, Search } from "lucide-react";

const galleryImages = [
  { url: "https://images.unsplash.com/photo-1520340356584-f9d27d758c5f", title: "Exterior Polish", type: "Full Polish" },
  { url: "https://images.unsplash.com/photo-1607860108855-64acf2078ed9", title: "Paint Restoration", type: "Rubbing" },
  { url: "https://images.unsplash.com/photo-1601362840469-51e4d8d59085", title: "Engine Cleaning", type: "Interior/Exterior" },
  { url: "https://images.unsplash.com/photo-1605515298946-d062f2e9da53", title: "Interior Detailing", type: "Deep Clean" },
  { url: "https://images.unsplash.com/photo-1552933061-90322eecd15d", title: "Wax Application", type: "Protection" },
  { url: "https://images.unsplash.com/photo-1541899481282-d53bffe3c35d", title: "Final Finish", type: "Gloss Enhancement" },
];

export default function Gallery() {
  return (
    <div className="pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tighter">
            Our <span className="text-gold">Gallery</span>
          </h1>
          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            Witness the transformation. Here's a look at some of the vehicles we've 
            restored to their former glory.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative aspect-[4/3] bento-card overflow-hidden !p-0 border-zinc-800"
            >
              <img
                src={`${img.url}?auto=format&fit=crop&q=80&w=800`}
                alt={img.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8" />
              
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                <div className="bg-gold text-black p-4 rounded-full shadow-2xl">
                  <Camera className="w-6 h-6" />
                </div>
              </div>

              <div className="absolute bottom-0 left-0 p-8 transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all">
                <span className="text-gold text-[10px] font-black uppercase tracking-[0.2em] mb-1 block">{img.type}</span>
                <h4 className="text-white font-black text-xl uppercase tracking-tighter">{img.title}</h4>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 bento-card border-zinc-800 text-center">
          <h3 className="text-2xl font-black uppercase tracking-tighter text-white mb-4">Want more updates?</h3>
          <p className="text-zinc-500 font-bold uppercase tracking-widest text-[10px] mb-8">Follow us on Instagram for daily work highlights</p>
          <a
            href="#"
            className="bg-black border border-zinc-800 hover:bg-zinc-800 text-white px-8 py-4 rounded-2xl font-black uppercase text-xs tracking-widest transition-all inline-flex items-center space-x-2"
          >
            <Search className="w-4 h-4" />
            <span>Follow Dashboard</span>
          </a>
        </div>
      </div>
    </div>
  );
}
