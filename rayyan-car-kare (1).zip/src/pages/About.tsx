import { motion } from "motion/react";
import { Award, Heart, Shield, Users } from "lucide-react";
import { cn } from "@/src/lib/utils";

export default function About() {
  return (
    <div className="pt-32 pb-24 px-4 md:px-8 max-w-7xl mx-auto min-h-screen">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-24">
        {/* Intro Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="md:col-span-12 bento-card flex flex-col md:flex-row items-center gap-12"
        >
          <div className="md:w-3/5">
            <div className="inline-flex items-center space-x-2 bg-gold/10 border border-gold/30 px-3 py-1 rounded-full text-gold text-[10px] font-black uppercase tracking-widest mb-6">
              <Heart className="w-3 h-3" />
              <span>Our Passion</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white mb-8 tracking-tighter uppercase leading-none">
              Restoring Shine, <br/><span className="text-gold">One Car at a Time</span>
            </h1>
            <div className="space-y-6 text-zinc-500 text-xs font-bold uppercase tracking-[0.2em] leading-loose">
              <p>
                Rayyan Car Kare was founded with a simple mission: to provide premium, 
                dealership-quality car detailing services right at our customers' preferred location.
              </p>
              <p>
                We understand that your car is one of your most valuable investments. 
                Our team of trained professionals uses only the highest quality products, 
                from 3M rubbing compounds to premium wax coatings.
              </p>
            </div>
          </div>
          <div className="md:w-2/5 aspect-square md:aspect-auto md:h-full relative overflow-hidden rounded-2xl">
            <img
              src="https://images.unsplash.com/photo-1605515298946-d062f2e9da53?auto=format&fit=crop&q=80&w=1000"
              alt="Detailing work"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          </div>
        </motion.div>

        {/* Commitment Cards */}
        {[
          { icon: Shield, title: "Quality First", desc: "We use only premium brands like 3M.", color: "border-zinc-800" },
          { icon: Award, title: "Expert Crew", desc: "Professionally trained detailing team.", color: "border-zinc-800" },
          { icon: Users, title: "Customer Focus", desc: "100% satisfaction guaranteed.", color: "border-gold/20" },
          { icon: Heart, title: "Detail Driven", desc: "Meticulous care for every vehicle.", color: "border-zinc-800" },
        ].map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className={cn("md:col-span-3 bento-card group hover:bg-zinc-800/20 transition-all", item.color)}
          >
            <div className="w-10 h-10 bg-zinc-800 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <item.icon className="w-5 h-5 text-gold" />
            </div>
            <h4 className="text-white font-black text-xl mb-3 uppercase tracking-tighter">{item.title}</h4>
            <p className="text-zinc-500 font-bold uppercase tracking-widest text-[9px] leading-relaxed">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
