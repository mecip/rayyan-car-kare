import { motion } from "motion/react";
import { CheckCircle2, ChevronRight, Info, MessageCircle, Sparkles } from "lucide-react";
import { SERVICES } from "@/src/constants";
import { Link } from "react-router-dom";
import { WhatsAppIcon } from "../components/WhatsAppIcon";
import { cn } from "@/src/lib/utils";

export default function Services() {
  return (
    <div className="pt-32 pb-24 px-4 md:px-8 max-w-7xl mx-auto min-h-screen">
      <div className="text-center mb-16">
        <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter uppercase leading-none">
          Our Detailing <br/><span className="text-gold">Packages</span>
        </h1>
        <p className="text-zinc-500 text-xs font-bold uppercase tracking-[0.2em] max-w-2xl mx-auto">
          Choose the perfect care for your vehicle. We deliver showroom excellence at your location.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {SERVICES.map((pkg, i) => (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            key={pkg.id}
            className={cn(
              "group bento-card relative overflow-hidden flex flex-col justify-between",
              pkg.id === 'rubbing-polish' ? "border-gold/30 ring-1 ring-gold/20 shadow-2xl shadow-gold/5" : ""
            )}
          >
            {pkg.id === 'rubbing-polish' && (
              <div className="absolute top-4 right-4 bg-gold text-black font-black text-[10px] px-3 py-1 rounded-full uppercase tracking-widest z-20">
                Most Popular
              </div>
            )}

            <div>
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h2 className="text-4xl font-black text-white mb-2 leading-none uppercase tracking-tighter">{pkg.name}</h2>
                  <p className="text-gold font-bold uppercase tracking-[0.2em] text-[10px]">{pkg.description}</p>
                </div>
                <div className="text-4xl font-black text-white tracking-tighter leading-none">
                  {pkg.price}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 mb-10">
                <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-2 border-b border-zinc-800 pb-2">Included In Package</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3">
                  {pkg.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-start space-x-3 text-zinc-400 group/item">
                      <CheckCircle2 className="w-4 h-4 text-gold shrink-0 mt-0.5 group-hover/item:scale-110 transition-transform" />
                      <span className="text-[11px] font-bold uppercase tracking-tight leading-tight">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-black/40 p-6 rounded-2xl border border-zinc-800/50 mb-10">
                <div className="flex items-center space-x-3 text-gold mb-3">
                  <Info className="w-4 h-4" />
                  <h4 className="font-black text-[10px] uppercase tracking-widest leading-none">Why this package?</h4>
                </div>
                <p className="text-zinc-500 text-[11px] font-bold leading-relaxed uppercase tracking-tighter italic">
                  {pkg.bestFor}
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Link
                to="/contact"
                className="flex-1 bg-gold hover:brightness-110 text-black px-8 py-4 rounded-2xl font-black uppercase tracking-[0.2em] text-xs transition-all shadow-xl shadow-gold/10 inline-flex items-center justify-center group"
              >
                <span>Book Now</span>
                <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
              <a
                href={`https://wa.me/919025049760?text=I want to book ${pkg.name}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-black hover:bg-zinc-800 text-gold border border-gold/30 px-8 py-4 rounded-2xl font-black uppercase tracking-[0.2em] text-xs transition-all inline-flex items-center justify-center space-x-2 hover:shadow-[0_0_20px_rgba(197,160,89,0.2)]"
              >
                <WhatsAppIcon className="w-5 h-5 fill-current" />
                <span>WhatsApp</span>
              </a>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Trust & Products Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mt-24 bento-card border-gold/20 bg-gradient-to-br from-black to-gold/10"
      >
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 space-y-6">
            <div className="inline-flex items-center space-x-2 bg-gold/10 border border-gold/30 px-3 py-1 rounded-full text-gold text-[10px] font-black uppercase tracking-[0.2em]">
              <span>Quality Assurance</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-white leading-none uppercase tracking-tighter">
              We Only Use <br/>
              <span className="text-gold italic">3M</span> Professional
            </h2>
            <p className="text-zinc-500 text-sm font-bold uppercase tracking-tight leading-relaxed">
              To ensure the best results and long-lasting protection, Rayyan Car Kare exclusively uses 3M automotive rubbing compounds, waxes, and detailing products. Your vehicle deserves nothing less than global industry standards.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              {['Paint Restoration', 'UV Protection', 'Ultra High Gloss', 'Scratch Removal'].map((tag) => (
                <div key={tag} className="px-4 py-2 bg-black/40 border border-zinc-800 rounded-xl text-[10px] font-black uppercase tracking-widest text-zinc-400">
                  {tag}
                </div>
              ))}
            </div>
          </div>
          <div className="w-full md:w-1/3 aspect-square max-w-[300px] relative">
            <div className="absolute inset-0 bg-gold/10 blur-3xl rounded-full" />
            <div className="relative bg-black border border-white/5 p-12 rounded-[3rem] h-full flex flex-col items-center justify-center shadow-2xl overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Sparkles className="w-20 h-20 text-white" />
              </div>
              <div className="text-8xl font-black text-gold italic tracking-tighter mb-2 group-hover:scale-110 transition-transform duration-500">3M</div>
              <p className="text-white font-black text-xs text-center uppercase tracking-widest leading-tight">
                Authentic Car <br/> Polish Products
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
