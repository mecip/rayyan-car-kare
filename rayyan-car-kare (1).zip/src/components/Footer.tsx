import { Car, MapPin, Phone, MessageCircle, Instagram, Facebook } from "lucide-react";
import { Link } from "react-router-dom";
import { CONTACT_INFO } from "@/src/constants";

export function Footer() {
  return (
    <footer className="bg-black py-16 px-4 md:px-8 max-w-7xl mx-auto border-t-2 border-gold/30 shadow-[0_-10px_40px_rgba(197,160,89,0.05)]">
      <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
        <div className="flex items-center space-x-4">
          <div className="relative w-24 h-12 overflow-visible">
            <svg 
              viewBox="0 0 120 50" 
              className="w-full h-full" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Thick Gold Swoop */}
              <path 
                d="M5 25C35 5 105 5 115 28C118 35 110 40 90 42" 
                stroke="#C5A059" 
                strokeWidth="4" 
                strokeLinecap="round"
              />
              {/* White Car Roof */}
              <path 
                d="M25 22C45 10 75 10 95 22" 
                stroke="white" 
                strokeWidth="3.5" 
                strokeLinecap="round"
              />
              {/* White Body Baseline */}
              <path 
                d="M15 26.5H105" 
                stroke="white" 
                strokeWidth="2.5" 
                strokeLinecap="round"
              />
              {/* Gold Accent Wedge on Left */}
              <path 
                d="M10 24L18 26.5L10 29V24Z" 
                fill="#C5A059" 
              />
            </svg>
          </div>
          <div className="flex flex-col -space-y-1">
            <span className="text-xl font-black italic tracking-tighter text-gold uppercase leading-none">
              RAYYAN
            </span>
            <span className="text-[9px] font-black uppercase tracking-[0.45em] text-white pl-0.5">
              CAR KARE
            </span>
          </div>
        </div>
        
        <div className="flex space-x-8">
          {["Home", "Services", "About", "Gallery", "Contact"].map((item) => (
            <Link
              key={item}
              to={item === "Home" ? "/" : `/${item.toLowerCase()}`}
              className="text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-gold transition-colors"
            >
              {item}
            </Link>
          ))}
        </div>

        {/* 3M Footer Badge */}
        <div className="flex items-center space-x-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-lg">
          <span className="text-gold font-black italic text-xs">3M</span>
          <span className="text-[8px] font-black uppercase tracking-widest text-zinc-500 border-l border-zinc-800/50 pl-2">Quality Standards</span>
        </div>

        <div className="flex flex-col items-center md:items-end">
          <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">
            © {new Date().getFullYear()} RAYYAN CAR KARE. ALL RIGHTS RESERVED.
          </p>
          <div className="flex space-x-4 mt-2">
             <span className="text-[10px] font-bold text-zinc-500 underline uppercase tracking-widest cursor-pointer hover:text-gold">Privacy Policy</span>
             <span className="text-[10px] font-bold text-zinc-500 underline uppercase tracking-widest cursor-pointer hover:text-gold">Terms</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
