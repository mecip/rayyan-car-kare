import { MessageCircle, Phone } from "lucide-react";
import { CONTACT_INFO } from "@/src/constants";

export function WhatsAppButton() {
  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsapp}?text=Hi Rayyan Car Kare, I'm interested in booking a car polish service.`;

  return (
    <div className="fixed bottom-6 right-6 flex flex-col space-y-4 z-50">
      <a
        href={`tel:${CONTACT_INFO.phone}`}
        className="bg-zinc-800 text-white p-4 rounded-full shadow-2xl hover:bg-zinc-700 transition-all transform hover:scale-110 active:scale-95 flex items-center justify-center border border-white/10"
        title="Call Now"
      >
        <Phone className="w-6 h-6" />
      </a>
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:bg-[#128C7E] transition-all transform hover:scale-110 active:scale-95 flex items-center justify-center"
        title="Chat on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 fill-current" />
      </a>
    </div>
  );
}
