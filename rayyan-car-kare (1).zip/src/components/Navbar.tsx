import { motion } from "motion/react";
import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { Menu, X, Car, MessageCircle } from "lucide-react";
import { WhatsAppIcon } from "./WhatsAppIcon";
import { cn } from "@/src/lib/utils";
import { CONTACT_INFO } from "@/src/constants";

const navLinks = [
  { name: "Home", href: "/" },
  { name: "Services", href: "/services" },
  { name: "About", href: "/about" },
  { name: "Gallery", href: "/gallery" },
  { name: "Contact", href: "/contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300",
        scrolled ? "bg-black/90 backdrop-blur-md py-3 shadow-xl" : "bg-transparent py-6"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-4 group">
            <div className="relative w-24 h-12 overflow-visible">
              <svg 
                viewBox="0 0 120 50" 
                className="w-full h-full" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Thick Gold Swoop */}
                <path 
                  d="M5 25C35 5 105 5 115 28C118 35 110 40 90 42" 
                  stroke="#C5A059" 
                  strokeWidth="4" 
                  strokeLinecap="round"
                />
                {/* White Car Roof */}
                <path 
                  d="M25 22C45 10 75 10 95 22" 
                  stroke="white" 
                  strokeWidth="3.5" 
                  strokeLinecap="round"
                />
                {/* White Body Baseline */}
                <path 
                  d="M15 26.5H105" 
                  stroke="white" 
                  strokeWidth="2.5" 
                  strokeLinecap="round"
                />
                {/* Gold Accent Wedge on Left */}
                <path 
                  d="M10 24L18 26.5L10 29V24Z" 
                  fill="#C5A059" 
                />
              </svg>
            </div>
            <div className="flex flex-col -space-y-1">
              <span className="text-xl md:text-2xl font-black italic tracking-tighter text-gold uppercase leading-none">
                RAYYAN
              </span>
              <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.45em] text-white pl-0.5">
                CAR KARE
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className={cn(
                  "text-sm font-bold uppercase tracking-wider transition-colors hover:text-gold",
                  location.pathname === link.href ? "text-gold" : "text-white"
                )}
              >
                {link.name}
              </Link>
            ))}
            <a
              href={`https://wa.me/${CONTACT_INFO.whatsapp}?text=Booking Request`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gold text-black px-6 py-2.5 rounded-full font-black text-sm shadow-[0_0_15px_rgba(197,160,89,0.2)] hover:shadow-[0_0_25px_rgba(197,160,89,0.5)] hover:brightness-110 transition-all transform hover:scale-105 active:scale-95 flex items-center space-x-2"
            >
              <WhatsAppIcon className="w-5 h-5 fill-current" />
              <span>WhatsApp Booking</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white p-2"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <motion.div
        initial={false}
        animate={isOpen ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
        className="md:hidden bg-black/95 overflow-hidden"
      >
        <div className="px-4 pt-2 pb-6 space-y-1 sm:px-3 border-t border-white/10">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.href}
              onClick={() => setIsOpen(false)}
              className={cn(
                "block px-3 py-4 text-base font-medium transition-colors hover:bg-white/5",
                location.pathname === link.href ? "text-gold" : "text-white"
              )}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/contact"
            onClick={() => setIsOpen(false)}
            className="block w-full text-center bg-gold text-black px-3 py-4 rounded-xl font-bold transition-all"
          >
            Book Now
          </Link>
        </div>
      </motion.div>
    </nav>
  );
}
