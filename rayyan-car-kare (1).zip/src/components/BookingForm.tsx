import { useForm } from "react-hook-form";
import { useState } from "react";
import { Send, CheckCircle2, Loader2 } from "lucide-react";
import { CONTACT_INFO } from "@/src/constants";

interface BookingFormProps {
  packageType?: string;
  className?: string;
}

export function BookingForm({ packageType = "", className = "" }: BookingFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: "",
      phone: "",
      carType: "",
      location: "",
      package: packageType,
    },
  });

  const onSubmit = async (data: any) => {
    setIsSubmitting(true);
    
    try {
      const response = await fetch("/api/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) throw new Error("Booking failed");

      await new Promise((resolve) => setTimeout(resolve, 500));
      setIsSuccess(true);
      reset();
    } catch (error) {
      console.error("Submission failed", error);
      alert("Something went wrong! Please call or WhatsApp us directly using the floating button.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="bg-zinc-900 border border-gold/30 p-8 rounded-2xl text-center flex flex-col items-center justify-center space-y-4">
        <CheckCircle2 className="w-16 h-16 text-gold" />
        <h3 className="text-2xl font-bold text-white">Booking Received!</h3>
        <p className="text-zinc-400">
          Thank you for choosing Rayyan Car Kare. We will contact you shortly to confirm your appointment.
        </p>
        <button
          onClick={() => setIsSuccess(false)}
          className="text-gold font-medium hover:underline pt-4"
        >
          Send another request
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className={`space-y-6 bento-card ${className}`}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gold pl-1">Customer Name</label>
          <input
            {...register("name", { required: "Name is required" })}
            placeholder="e.g. John Doe"
            className="w-full bg-black border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:border-gold outline-none transition-all placeholder:text-zinc-700 font-bold"
          />
          {errors.name && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest pl-1">{errors.name.message as string}</p>}
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gold pl-1">Phone Number</label>
          <input
            {...register("phone", { required: "Phone is required" })}
            placeholder="+91 XXXXX XXXXX"
            className="w-full bg-black border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:border-gold outline-none transition-all placeholder:text-zinc-700 font-bold"
          />
          {errors.phone && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest pl-1">{errors.phone.message as string}</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gold pl-1">Car Model</label>
          <input
            {...register("carType", { required: "Car model is required" })}
            placeholder="e.g. Toyota Camry"
            className="w-full bg-black border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:border-gold outline-none transition-all placeholder:text-zinc-700 font-bold"
          />
          {errors.carType && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest pl-1">{errors.carType.message as string}</p>}
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gold pl-1">Location</label>
          <input
            {...register("location", { required: "Location is required" })}
            placeholder="e.g. Saligramam"
            className="w-full bg-black border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:border-gold outline-none transition-all placeholder:text-zinc-700 font-bold"
          />
          {errors.location && <p className="text-red-500 text-[10px] font-bold uppercase tracking-widest pl-1">{errors.location.message as string}</p>}
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-gold pl-1">Select Package</label>
        <div className="relative">
          <select
            {...register("package")}
            className="w-full bg-black border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:border-gold outline-none transition-all appearance-none font-bold cursor-pointer"
          >
            <option value="">Choose a detailing service</option>
            <option value="Rubbing & Polish Package – ₹5,999">Rubbing & Polish Package – ₹5,999</option>
            <option value="Wax Polish Package – ₹2,999">Wax Polish Package – ₹2,999</option>
          </select>
          <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
            <Send className="w-4 h-4 rotate-90" />
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-gold hover:brightness-110 text-black font-black uppercase tracking-[0.2em] text-xs py-5 rounded-2xl transition-all flex items-center justify-center space-x-2 disabled:opacity-70 disabled:cursor-not-allowed shadow-xl shadow-gold/10"
      >
        {isSubmitting ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <>
            <span>Request Booking</span>
          </>
        )}
      </button>
      <p className="text-[9px] text-center text-zinc-600 font-bold uppercase tracking-widest">
        Professional Doorstep Service • No hidden charges
      </p>
    </form>
  );
}
