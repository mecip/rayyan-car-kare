export interface ServicePackage {
  id: string;
  name: string;
  price: string;
  description: string;
  benefits: string[];
  bestFor: string;
}

export const CONTACT_INFO = {
  phone: "+919025049760",
  whatsapp: "919025049760",
  displayPhone: "+91 90250 49760",
  email: "rayyancarkare@gmail.com",
  address: "No 18 Mosque Street, Saligramam, Chennai - 600093",
};

export const SERVICES: ServicePackage[] = [
  {
    id: "rubbing-polish",
    name: "Rubbing & Polish Package",
    price: "₹5,999",
    description: "Deep Paint Restoration & Premium Shine",
    benefits: [
      "Full Body Wax Polish",
      "3M Full Body Rubbing & Polishing",
      "Dust & Tar Removal",
      "Complete Interior & Exterior Cleaning",
      "Tyre & Dashboard Polishing",
      "Plastic Parts Polishing",
      "Seat Stain & Roof Cleaning",
      "Vacuum Cleaning"
    ],
    bestFor: "Old paint, swirl marks, dull finish"
  },
  {
    id: "wax-polish",
    name: "Wax Polish Package",
    price: "₹2,999",
    description: "Paint Protection & Gloss Enhancement",
    benefits: [
      "Full Body Wax Polish",
      "Exterior Shampoo Wash",
      "Dust & Tar Removal",
      "Complete Interior & Exterior Cleaning",
      "Tyre & Dashboard Polishing",
      "Plastic Parts Polishing",
      "Seat Stain & Roof Cleaning",
      "Vacuum Cleaning"
    ],
    bestFor: "Regular maintenance & shine protection"
  }
];
